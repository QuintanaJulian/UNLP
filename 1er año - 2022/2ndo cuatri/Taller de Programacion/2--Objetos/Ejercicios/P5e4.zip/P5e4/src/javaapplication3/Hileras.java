/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author juliq
 */
public class Hileras extends Coros{
    private Coristas [][] Orden;
    private int DimXF, DimYF;
    private int DimYL;
    private int DimXL;

    public Hileras(int DimXF, int DimYF, Director Dir, String nCoro) {
        super(Dir, nCoro);
        this.DimXF = DimXF;
        this.DimYF = DimYF;
        Orden = new Coristas[DimXF][DimYF];
    }

    public int getDimXF() {
        return DimXF;
    }

    public int getDimYF() {
        return DimYF;
    }

    public int getDimYL() {
        return DimYL;
    }

    public int getDimXL() {
        return DimXL;
    }
    
    
    
    
    
    
    public void newCoristas (Coristas nuevoCorista){
            if ((DimXL<DimXF) && (DimYL<DimYF))
                Orden[DimXL][DimYL] = nuevoCorista;
            if ((DimXL + 1) < DimXF)
                DimXL++;
            else {DimYL++;  DimXL = 0;}

        
    }

    @Override
    public boolean CoroLLeno() {
        if ((DimXL == 0) && (DimYL == DimYF))
            return true;
        else return false;
    }

    @Override
    public boolean CoroEnOrden() {
        int i, primero, ant;
        int j = 0;
        ant = 9999;
        for (i=0; i< DimYF; i++){
            primero=  Orden[0][i].getTono();
            for (j=0; j < DimXF; j++) {
                if (primero != (Orden[j][i].getTono()))
                    return false;
            }
            if (ant < (Orden[0][i].getTono()))
                return false;
            ant = Orden[0][i].getTono();
        }
        return true;       
    }

    @Override
    public String toString() {
        String aux;
        aux = super.toString() + System.lineSeparator() + System.lineSeparator();
        
        int i,j;
        
            for (j=0; j < DimYF; j++) 
                for (i=0; i< DimXF; i++)
                aux = (aux + "       " + Orden[i][j].toString() + System.lineSeparator());
            
        
        return aux;
    }
    
    
    
    
}
