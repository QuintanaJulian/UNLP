/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author juliq
 */
public class Director {
    private String Nombre;
    private int DNI;
    private int Edad;
    private int Antiguedad;

    public Director(String Nombre, int DNI, int Edad, int Antiguedad) {
        this.Nombre = Nombre;
        this.DNI = DNI;
        this.Edad = Edad;
        this.Antiguedad = Antiguedad;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public int getAntiguedad() {
        return Antiguedad;
    }

    public void setAntiguedad(int Antiguedad) {
        this.Antiguedad = Antiguedad;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Director: Nombre= ").append(Nombre);
        sb.append(", DNI= ").append(DNI);
        sb.append(", Edad= ").append(Edad);
        sb.append(", Antiguedad= ").append(Antiguedad);
        return sb.toString();
    }
    
    
    
}
