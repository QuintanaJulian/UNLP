/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author juliq
 */
public abstract class Coros {
    private Director Dir;
    private String nombre;

    public Coros(Director Dir, String nombre) {
        this.Dir = Dir;
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
    
    
    
    public abstract boolean CoroLLeno();
    
    public abstract boolean CoroEnOrden();

    @Override
    public String toString() {
        return ("Coro: " + getNombre() + System.lineSeparator()+ "Dirigido por el " + Dir.toString());
    }
  
        
            
       
    
}
