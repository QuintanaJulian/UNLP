/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author juliq
 */
public class Semicircular extends Coros {
    private Coristas [] Orden;
    private int DimF;
    private int DimL = 0;

    public Semicircular(int DimF, Director Dir, String nCoro) {
        super(Dir, nCoro);
        this.DimF = DimF;
        Orden = new Coristas [DimF];
    }
    
    public void newCoristas (Coristas nuevoCorista){
        if (DimL < DimF) {
            
            Orden[DimL]= nuevoCorista;
            DimL++;
        }
    }

    public int getDimF() {
        return DimF;
    }

    public int getDimL() {
        return DimL;
    }
    
    
    @Override
    public boolean CoroLLeno() {
        if (DimL == (DimF))
            return true;
        else return false;
    }

    
    @Override
    public boolean CoroEnOrden() {
        int ant;
        int i= 0;
        ant = Orden[i].getTono();
        for (i=0; i < (DimL); i++) {
            if (ant >= Orden[i].getTono()){
                ant = Orden[i].getTono();
                
            } else return false;
        }           
        return true;        
    }

    @Override
    public String toString() {
        String aux;
        int i;
        aux = (super.toString() + System.lineSeparator() + System.lineSeparator());
        for (i=0; i < DimL; i++)
            aux = (aux + "       " +Orden[i].toString() + System.lineSeparator());
    
        return aux;
    }
            
    
    
}
