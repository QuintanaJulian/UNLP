/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author juliq
 */
public class Coristas {
    private String Nombre;
    private int DNI;
    private int Edad;
    private int Tono;

    public Coristas(String Nombre, int DNI, int Edad, int Tono) {
        this.Nombre = Nombre;
        this.DNI = DNI;
        this.Edad = Edad;
        this.Tono = Tono;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public int getTono() {
        return Tono;
    }

    public void setTono(int Tono) {
        this.Tono = Tono;
    }

    @Override
    public String toString() {
        return "Coristas{" + "Nombre=" + Nombre + ", DNI=" + DNI + ", Edad=" + Edad + ", Tono=" + Tono + '}';
    }
    
    
    
}
