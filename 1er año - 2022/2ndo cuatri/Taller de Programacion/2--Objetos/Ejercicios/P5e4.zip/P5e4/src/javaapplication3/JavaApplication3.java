/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author juliq
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Director D1= new Director("Juan", 24564639, 46, 30);
        
        Semicircular S1 = new Semicircular(3, D1, "La banda del patio");
        
        Coristas C1= new Coristas("Alberto", 34456987, 26, 3);
        S1.newCoristas(C1);
        
        Coristas C2= new Coristas("Ramon", 34456987, 26, 2);
        S1.newCoristas(C2);
        Coristas C3= new Coristas("Gaston", 12353617, 20, 1);
        S1.newCoristas(C3);
        
        System.out.println(S1.CoroLLeno());
        System.out.println("DimF " + S1.getDimF()+ "  DimL " + S1.getDimL());
        System.out.println(S1.toString());
        System.out.println("El coro esta en orden: " + S1.CoroEnOrden());
        
        
        
        
        Director D2= new Director("Juan", 24564639, 46, 30);
        
        Hileras H1 = new Hileras(2, 2, D2, "Mozart");
        
        Coristas C4= new Coristas("Alberto", 34456987, 26, 3);
        H1.newCoristas(C4);
        
        Coristas C5= new Coristas("Ramon", 34456987, 26, 3);
        H1.newCoristas(C5);
        Coristas C6= new Coristas("Gaston", 12353617, 20, 4);
        H1.newCoristas(C6);
        Coristas C7= new Coristas("Ferrari", 38765455, 25, 4);
        H1.newCoristas(C7);
        
        System.out.println(H1.CoroLLeno());
        System.out.println("DimXF " + H1.getDimXF()+ "  DimXL " + H1.getDimXL());
        System.out.println("DimYF " + H1.getDimYF()+ "  DimYL " + H1.getDimYL());
        System.out.println(H1.toString());
        System.out.println("El coro esta en orden: " + H1.CoroEnOrden());        
        
        
        
        
        
        
    }
    
}
