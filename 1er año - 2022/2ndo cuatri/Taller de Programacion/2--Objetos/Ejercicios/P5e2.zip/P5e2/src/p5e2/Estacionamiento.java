/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5e2;

/**
 *
 * @author juliq
 */
public class Estacionamiento {
    private String Nombre;
    private String Direccion;
    private double Apertura;
    private double Cierre;
    private Auto [][] Lugares;
    private int Plantas;
    private int Plazas;

    public Estacionamiento(String Nombre, String Direccion) {
        this.Nombre = Nombre;
        this.Direccion = Direccion;
        this.Apertura = 8.00;
        this.Cierre = 21.00;
        Lugares= new Auto [5][10];
        
    }

    public Estacionamiento(String Nombre, String Direccion, double Apertura, double Cierre, int Planta, int Plaza) {
        this.Nombre = Nombre;
        this.Direccion = Direccion;
        this.Apertura = Apertura;
        this.Cierre = Cierre;
        this.Plantas = Planta;
        this.Plazas = Plaza;        
        Lugares= new Auto [Plantas][Plazas];
        int i = 0;
        int j;
        Auto A= new Auto("", "Vacio");
        while (i < Plantas){
            j = 0;
            while (j < Plazas){
                Lugares[i][j]= A;
                j++;
            } 
            i++;
        }
       
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public double getApertura() {
        return Apertura;
    }

    public void setApertura(double Apertura) {
        this.Apertura = Apertura;
    }

    public double getCierre() {
        return Cierre;
    }

    public void setCierre(double Cierre) {
        this.Cierre = Cierre;
    }

    public int getPlantas() {
        return Plantas;
    }

    public int getPlazas() {
        return Plazas;
    }
    
    public void nuevoAuto (Auto A, int Planta, int Plaza){
        this.Lugares [Planta][Plaza] = A;      
        
    } 
    /*
    public String buscarPatente (String PatBuscada){
        int P= 0;
        int L = 0;
        while  ((P < Plantas) && (!PatBuscada.equals(Lugares[P][L].getPatente()))) {
            
            
            while ((L < Plazas) && (!PatBuscada.equals(Lugares[P][L].getPatente())))
                L++;
            
            if (( L< Plazas)&& (PatBuscada.equals(Lugares[P][L].getPatente()))) {
                return ("Se encuentra en la Planta " + P + ", lugar " + L);
                
            }
        P++;
        L = 0;
                
        }
      
     // if (!PatBuscada.equals(Lugares[P][L].getPatente())) 
         return( "Auto Inexistente. " );
    }
    */
    
        public String buscarPatente(String patente){
        
        for(int P=0;P<Plantas;P++){
            for(int L=0;L<Plazas;L++){
                if(Lugares[P][L].getPatente().equals(patente)){
                    return "Se encuentra en la Planta " + P + ", lugar " + L;
                }
            }
        }
        return "Auto inexistente";
    }
    
    
    
    
    
     
    public String leerEstacionamiento (){
        int P= 0;
        int L= 0;
        String Aux = "";
        while  (P < Plantas)  {
            L = 0;
            while (L < Plazas) {
                Aux = (Aux + " La planta " + (P + 1) + " lugar " + (L + 1) + " hay " + (Lugares[P][L].getPatente()) + ".   ") ;
                L++;
            }
            Aux = Aux + System.lineSeparator();    
            P++;
        }
        return Aux;
    }
    
    
   public int autosPlazas (int Lugar) {
       int P = 0;
       int Aux = 0;
       Lugar--;
       while (P < Plantas){
           if ( !Lugares[P][(Lugar)].getPatente().equals("Vacio"))
               Aux= Aux + 1;
           P++;
       }
       return Aux;
   }   
}
