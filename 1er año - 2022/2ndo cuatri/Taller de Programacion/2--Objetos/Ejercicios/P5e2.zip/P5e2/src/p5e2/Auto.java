/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5e2;

/**
 *
 * @author juliq
 */
public class Auto {
    private String Dueno;
    private String Patente;

    public Auto(String Dueno, String Patente) {
        this.Dueno = Dueno;
        this.Patente = Patente;
    }

    public String getDueno() {
        return Dueno;
    }

    public void setDueno(String Dueno) {
        this.Dueno = Dueno;
    }

    public String getPatente() {
        if (!Patente.equals("null"))
        return Patente;
        else return ("Vacio");
    }

    public void setPatente(String Patente) {
        this.Patente = Patente;
    }

    @Override
    public String toString() {
        return "Auto{" + "Dueno=" + Dueno + ", Patente=" + Patente + '}';
    }


    
    
}
