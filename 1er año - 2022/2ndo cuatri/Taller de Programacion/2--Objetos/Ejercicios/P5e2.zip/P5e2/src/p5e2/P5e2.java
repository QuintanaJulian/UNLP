/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5e2;

    import PaqueteLectura.GeneradorAleatorio;
/**
 *
 * @author juliq
 */
public class P5e2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Estacionamiento Parking = new Estacionamiento("TuPapa", "99 y 9", 9.45, 24.00, 3 , 3);
        
        Auto A= new Auto("Juan", "OPV043");
        Parking.nuevoAuto (A, 2, 1);
        int i;
        GeneradorAleatorio.iniciar();
        for (i=1; i<6; i++){
            A= new Auto("Joaquin", GeneradorAleatorio.generarString(6));
            Parking.nuevoAuto(A, GeneradorAleatorio.generarInt(3), GeneradorAleatorio.generarInt(3));
        }
        int PlazaBuscada = 1;
                
                
        System.out.println(Parking.leerEstacionamiento());
        System.out.println ("Cantidad de autos en Plaza "+ PlazaBuscada + " = "  + Parking.autosPlazas(PlazaBuscada));
        System.out.println (Parking.buscarPatente("OPV043"));
    }
    
}
