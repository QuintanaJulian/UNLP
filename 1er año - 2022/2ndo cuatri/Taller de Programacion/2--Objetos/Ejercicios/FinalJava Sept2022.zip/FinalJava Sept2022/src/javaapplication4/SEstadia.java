/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author juliq
 */
public class SEstadia extends Subsidios {
    String Destino;
    double Pasaje;
    int Dias;
    double Precio;

    public SEstadia(String Destino, double Pasaje, int Dias, double Precio, String Investigador, String Plan, String Fecha) {
        super(Investigador, Plan, Fecha);
        this.Destino = Destino;
        this.Pasaje = Pasaje;
        this.Dias = Dias;
        this.Precio = Precio;
    }

    @Override
    public double MontoT() {
        double aux;
        aux = Dias * Precio;
        return Pasaje + aux;
    }

    @Override
    public String toString() {
        return "Subsidio de estadia: " + System.lineSeparator() + super.toString() + "     " + "Monto total= "+ MontoT() + ", Destino= " + Destino + ", Dia/s= " + Dias ;
    }


    
    
    
    
}
