/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author juliq
 */
public class JavaApplication4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SEstadia E1 = new SEstadia ("Misiones", 35000, 5, 3000, "Corina Graciano", "Viaje Campaña", "20/9/2022" );
        System.out.println (E1.toString());
    
        SBienes B1 = new SBienes(2, "Leonardo Quintana", "Partes Electronica", "11/10/2022");
        B1.setBien("MotherBoards", 5, 2000.1);
        B1.setBien("CPUs", 2, 15000.50);
        System.out.println(B1.toString());
    }
    
}
