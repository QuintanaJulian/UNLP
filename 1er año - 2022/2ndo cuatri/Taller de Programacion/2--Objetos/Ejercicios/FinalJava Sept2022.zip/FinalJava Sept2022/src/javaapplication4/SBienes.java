/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author juliq
 */
public class SBienes extends Subsidios {
    Bien [] Bienes;
    int DimL;
    int DimF;

    public SBienes(int cantBienes, String Investigador, String Plan, String Fecha) {
        super(Investigador, Plan, Fecha);
        this.DimF = cantBienes;
        Bienes = new Bien [DimF];
        int i;
        for (i = 0; i<DimF; i++)
                Bienes[i] = null;
    }
    
    public void setBien (String Descripcion, int Cant, double Precio){
        if (DimL < DimF){
            Bien nuevoBien= new Bien(Descripcion, Cant, Precio);
            Bienes[DimL] = nuevoBien;
            DimL++;
        }         
    }

    @Override
    public double MontoT() {
        double aux = 0;
        int i;
        for (i = 0; i<DimL; i++)
            aux= aux + Bienes[i].getTotal();
        
        return aux;
    }

    @Override
    public String toString() {
        String aux= "";
        int i;
        for (i=0; i<DimL; i++)
            aux= aux + System.lineSeparator() + "     " + "Razon " + (i+1) +": " + Bienes[i].getDescripcion() ;
                
        return "Subsidio de bienes: " + System.lineSeparator() + super.toString()+ "Monto total= "+ MontoT() + aux ;
    }
    

       
    
    
    
    
}
