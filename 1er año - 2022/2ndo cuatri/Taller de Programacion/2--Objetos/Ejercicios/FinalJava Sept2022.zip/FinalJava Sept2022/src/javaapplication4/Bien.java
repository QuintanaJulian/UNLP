/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication4;

/**
 *
 * @author juliq
 */
public class Bien {
    String Descripcion;
    int Cantidad;
    double Precio;

    public Bien(String Descripcion, int Cantidad, double Precio) {
        this.Descripcion = Descripcion;
        this.Cantidad = Cantidad;
        this.Precio = Precio;
    }

    public double getTotal (){
        return (Cantidad * Precio);
    }

    public String getDescripcion() {
        return Descripcion;
    }

    
}

