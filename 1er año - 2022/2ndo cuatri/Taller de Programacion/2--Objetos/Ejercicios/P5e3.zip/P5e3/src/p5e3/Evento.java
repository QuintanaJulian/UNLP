/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5e3;

/**
 *
 * @author juliq
 */
public class Evento extends Recital{
    private String Motivo;
    private String Contractor;
    private int Dia;

    public String getMotivo() {
        return Motivo;
    }

    public void setMotivo(String Motivo) {
        this.Motivo = Motivo;
    }

    public String getContractor() {
        return Contractor;
    }

    public void setContractor(String Contractor) {
        this.Contractor = Contractor;
    }

    public int getDia() {
        return Dia;
    }

    public void setDia(int Dia) {
        this.Dia = Dia;
    }

    public Evento(String Motivo, String Contractor, int Dia, String Banda, int cant) {
        super(Banda, cant);
        this.Motivo = Motivo;
        this.Contractor = Contractor;
        this.Dia = Dia;
    }
    
    public void actuar (){
        String Aux;
        if (getMotivo().equals("beneficencia"))
            Aux = "Recuerden colaborar con ";
        else if (getMotivo().equals("TV"))
            Aux = "Saludos amigos televidentes";
        else Aux = ("Un feliz cumpleaños para" + getContractor());
        System.out.println (Aux);
        super.actuar();
    }

    @Override
    public double calcularCosto() {
        double Aux;
        if (getMotivo().equals("beneficencia"))
            Aux = 0.0;
        else if (getMotivo().equals("TV"))
            Aux = 50000.00;
        else Aux = 150000.00;
        return Aux;
    }
            
    
    
}
