/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5e3;

/**
 *
 * @author juliq
 */
public class Gira extends Recital{
    private String Nombre;
    private fecha [] Fechas;
    private int FechaAct = 0;
    private int dimL = 0;
    int dimF;

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public fecha[] getFechas() {
        return Fechas;
    }

    public int getFechaAct() {
        return FechaAct;
    }

    public void setFechaAct(int FechaAct) {
        this.FechaAct = FechaAct;
    }

    public Gira(String Nombre, int cantFechas, String Banda, int cantTemas) {
        super(Banda, cantTemas);
        this.dimF = cantFechas;
        this.Nombre = Nombre;
        Fechas = new fecha[dimF];
    }
    
    public void agregarFecha (fecha nuevaFecha){
        
     //   Fechas[dimL] = nuevaFecha;
        dimL++;
        int i = 0; 
        int ult;
        while ((i < dimL-1) && (Fechas[i].getDia() < nuevaFecha.getDia()))
            i++;
        
        for (ult = dimL-1; ult >= i; ult--)
            Fechas[(ult+1)]= Fechas [ult]; 
        
        Fechas[i] = nuevaFecha;     
    }

    
    public void actuar() {
        
        System.out.println("Buenas noches " + Fechas[getFechaAct()].getCiudad());
        super.actuar();
        setFechaAct(FechaAct + 1);
    }

    
    public double calcularCosto() {
        double Aux;
        Aux = (30000 * (getFechaAct()));
        return Aux;
    }
    
    
    
    
    
    
}
