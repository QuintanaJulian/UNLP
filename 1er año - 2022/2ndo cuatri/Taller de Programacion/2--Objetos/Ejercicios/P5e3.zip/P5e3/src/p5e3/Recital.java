/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5e3;

import java.util.stream.IntStream;

/**
 *
 * @author juliq
 */
public abstract class Recital {
    private String Banda;
    private String [] Temas;
    int dimL = 0;

    public String getBanda() {
        return Banda;
    }

    public void setBanda(String Banda) {
        this.Banda = Banda;
    }

    public String[] getTemas() {
        return Temas;
    }


    public Recital(String Banda, int cant) {
        this.Banda = Banda;
        Temas = new String[cant];
    }

    public void agregarTema (String NombreTema){
        Temas[dimL]= NombreTema;
        dimL++;
    }
    
    public void actuar (){
        int i;
        for (i=0; i<dimL; i++)
            System.out.println("El proximo tema sera: " + Temas[i] + System.lineSeparator());
    }
    
    public abstract double calcularCosto();
           
    
    
    
    
}
