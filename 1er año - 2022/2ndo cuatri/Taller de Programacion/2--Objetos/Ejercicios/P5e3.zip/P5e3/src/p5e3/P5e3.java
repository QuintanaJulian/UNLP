/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5e3;
//import PaqueteLectura.GeneradorAleatorio;
//import PaqueteLectura.Lector;
/**
 *
 * @author juliq
 */
public class P5e3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        Gira G1 = new Gira("Ultimo tour del mundo", 3 , "Bas Bunny", 2);
        
        fecha nuevaFecha = new fecha("La Plata" , 22);
        G1.agregarFecha(nuevaFecha);
      //  nuevaFecha.setCiudad("Berisso"); nuevaFecha.setDia(25);
        fecha nuevaFecha2 = new fecha("Cordoba", 20);
        G1.agregarFecha(nuevaFecha2);
        G1.agregarTema("Yo perreo sola");
        G1.agregarTema("Una noche en miami");
        
        
        
        Evento E1 = new Evento("Cumple", "Julián", 11, "Calle 13",  2);
       
        E1.agregarTema("Muerte en Hawaii");
        E1.agregarTema("Multiviral");
        
        G1.actuar();
        G1.actuar();

        E1.actuar();
        
        System.out.println (G1.calcularCosto());
        System.out.println (E1.calcularCosto());
    }
    
}
