/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p5e3;

/**
 *
 * @author juliq
 */
public class fecha {
    private String Ciudad;
    private int Dia;

    public String getCiudad() {
        return Ciudad;
    }

    public void setCiudad(String Ciudad) {
        this.Ciudad = Ciudad;
    }

    public int getDia() {
        return Dia;
    }

    public void setDia(int Dia) {
        this.Dia = Dia;
    }

    public fecha(String Ciudad, int Dia) {
        this.Ciudad = Ciudad;
        this.Dia = Dia;
    }





}
