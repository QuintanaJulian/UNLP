/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pparcial1;

/**
 *
 * @author Juli
 */
public class PParcial1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Concurso C1= new Concurso(2);
        
        Participantes Part1= new Participantes(23564512, "Joaquina", 10);
        Participantes Part2= new Participantes(36654023, "Joaquin", 40);
        Pareja P1 = new Pareja( Part1 , Part2 , "Flamenco" );
        C1.setPareja(P1);
        
        Participantes Part3= new Participantes(44519668, "Ernesto", 20);
        Participantes Part4= new Participantes(38654023, "Ernesta", 33);
        Pareja P2 = new Pareja( Part3 , Part4 , "Flamenco" );
        C1.setPareja(P2);
        
        System.out.println (C1.getDiferencia(0));
        System.out.println (C1.getDiferencia(1));
        
        int i = C1.getMayorDiferencia();
        
        System.out.println ("Los participantes con mas diferencia de edad son:"+ System.lineSeparator()
                + "       " + C1.getPareja(i).getParticipante1().getNombre() + " y " + 
                C1.getPareja(i).getParticipante2().getNombre() + " con " + C1.getDiferencia(i) + " años de diferencia");
        
    }
    
}
