/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pparcial1;

/**
 *
 * @author Juli
 */
public class Pareja {
    Participantes Participante1;
    Participantes Participante2;
    String Estilo;

    public Pareja(Participantes Participante1, Participantes Participante2, String Estilo) {
        this.Participante1 = Participante1;
        this.Participante2 = Participante2;
        this.Estilo = Estilo;
    }

    public Participantes getParticipante1() {
        return Participante1;
    }

    public Participantes getParticipante2() {
        return Participante2;
    }

    public String getEstilo() {
        return Estilo;
    }
    
    
    
            
}
