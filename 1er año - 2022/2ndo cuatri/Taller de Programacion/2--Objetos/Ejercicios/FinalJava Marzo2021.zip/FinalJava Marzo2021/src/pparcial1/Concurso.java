/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pparcial1;

/**
 *
 * @author Juli
 */
public class Concurso {
    Pareja[]Grupos;
    int DimL;

    public Concurso(int Cant) {
        Grupos= new Pareja[Cant];
    }

    public Pareja getPareja(int i) {
        return Grupos[i];
    }

    public Pareja[] getGrupos() {
        return Grupos;
    }
    
    
    
    
    public void setPareja (Pareja P){
        Grupos[DimL] = P;
        DimL++;
    }
    
    public int getDiferencia (int Pos){
        int aux1, aux2;
        aux1 = Grupos[Pos].getParticipante1().getEdad();
        aux2 = Grupos[Pos].getParticipante2().getEdad();
        if (aux1<aux2) return (aux2 - aux1);
        else return  (aux1 - aux2);
        
    }
    
    public int getMayorDiferencia () {
        int i, aux; 
        int pareja = 0;
        int temp = -999;
        for (i= 0; i < DimL; i++){
            aux = getDiferencia(i);
            if (aux > temp){
                temp= aux;
                pareja = i;
            }
            
        }
        return pareja;    
        
        
    }
    
}
