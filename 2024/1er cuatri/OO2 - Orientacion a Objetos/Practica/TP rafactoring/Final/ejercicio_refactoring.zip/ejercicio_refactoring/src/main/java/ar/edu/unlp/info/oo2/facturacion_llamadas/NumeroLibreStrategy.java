package ar.edu.unlp.info.oo2.facturacion_llamadas;


public interface NumeroLibreStrategy {
	
	public String obtenerNumeroLibre(GestorNumerosDisponibles gestor);
}
	

    