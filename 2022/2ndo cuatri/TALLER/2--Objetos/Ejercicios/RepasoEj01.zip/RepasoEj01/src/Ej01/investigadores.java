/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ej01;

/**
 *
 * @author fdiaz
 */
public class investigadores {
    private int dimSub= 5;
    private int dimL = 0;
    private String nombreInvestigador;
    private int categoria;
    private String especialidad;
    private subsidios ss;
    private subsidios [] vectorSs = new subsidios[dimSub];
    private subsidios [] ssNo = new subsidios[dimSub];   
    
    public investigadores(String nombreInvestigador, int categoria, String especialidad) {
        this.nombreInvestigador = nombreInvestigador;
        this.categoria = categoria;
        this.especialidad = especialidad;
    }

    public investigadores() {
    }
   
    public void setNombreInvestigador(String nombreInvestigador) {
        this.nombreInvestigador = nombreInvestigador;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public void agregarSubsudio(subsidios ss) {
        if(dimL<dimSub){
            vectorSs[dimL] = ss;
            dimL++;
        }
    }

    public String getNombreInvestigador() {
        return nombreInvestigador;
    }

    public int getCategoria() {
        return categoria;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public subsidios getSs() {
        return ss;
    }
    
    public double montoTotal(){
        double m = 0;
        for(int i=0;i<dimL;i++){
            if(vectorSs[i].isOtorgado()==true)
            m = m + vectorSs[i].getMonto();
        }
        return m;
    }
    
    public void otorgarTodos(String nombreInvestigador){
        for(int i=0;i<dimL;i++){
            if(vectorSs[i].isOtorgado()==false){
                ssNo[i] = vectorSs[i];
                System.out.println("monto: " + ssNo[i].getMonto() + " motivo: " + ssNo[i].getMotivo());
            }
        }
    }
    
    public String toString(){
        String aux1;
        aux1 = "nombre: " + nombreInvestigador + " - categoria: " + categoria + " - especialidad: " + especialidad + 
                " - dinero total de los subsidios del investigador: " + montoTotal() + "\n";
        return aux1;
    }
    
}
