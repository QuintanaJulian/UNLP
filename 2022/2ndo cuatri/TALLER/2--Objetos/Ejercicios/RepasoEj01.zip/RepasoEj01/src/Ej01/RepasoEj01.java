/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ej01;

import PaqueteLectura.Lector;
public class RepasoEj01 {

   
    public static void main(String[] args) {
        proyectos p = new proyectos("manhattan", 123, "Pablito patas cortas");
        
        investigadores inv1 = new investigadores("floricienta",1,"analisis de cocaina");
        investigadores inv2 = new investigadores("luisito",2,"aspirar la cocaina");
        investigadores inv3 = new investigadores("rokefeler",3,"distribucion");
        
        p.agregarInvestigador(inv1);
        p.agregarInvestigador(inv2);
        p.agregarInvestigador(inv3);
        
        subsidios sub1 = new subsidios(50000, "luisito nos dejo sin cocaina");
        subsidios sub2 = new subsidios(150, "cumple de floricienta");
        subsidios sub3 = new subsidios(2000, "cambio de cubierta");
        subsidios sub4 = new subsidios(9000, "se rompio el microonas");
        subsidios sub5 = new subsidios(15, "tengo hambre");
        subsidios sub6 = new subsidios(8000, "nueva ,aquina de analisis");
        
        sub1.setOtorgado(true);
        sub2.setOtorgado(true);
        
        
        inv1.agregarSubsudio(sub1);
        inv1.agregarSubsudio(sub2);
        
        inv2.agregarSubsudio(sub3);
        inv2.agregarSubsudio(sub4);
        
        inv3.agregarSubsudio(sub5);
        inv3.agregarSubsudio(sub6);
        
        System.out.println(p.toString());
    }   
    
}
