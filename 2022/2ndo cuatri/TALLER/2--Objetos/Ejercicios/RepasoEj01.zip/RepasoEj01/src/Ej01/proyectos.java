/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ej01;

/**
 *
 * @author fdiaz
 */
public class proyectos {
    private int dimInv = 50;
    private int dimL = 0;
    private String nombreProyecto;
    private int codigo;
    private String nombreDirector;
    private investigadores investigador;
    private investigadores [] inv = new investigadores[dimInv]; 

    public proyectos(String nombreProyecto, int codigo, String nombreDirector) {
        this.nombreProyecto = nombreProyecto;
        this.codigo = codigo;
        this.nombreDirector = nombreDirector;
    }    
    public proyectos(){
        
    }
    
    public void setNombreProyecto(String nombreProyecto) {
        this.nombreProyecto = nombreProyecto;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setNombreDirector(String nombreDirector) {
        this.nombreDirector = nombreDirector;
    }
    
    
    public void agregarInvestigador(investigadores investigador) {
        if(dimL < dimInv){
            inv[dimL] = investigador;
            dimL++;
        }           
    }

    public String getNombreProyecto() {
        return nombreProyecto;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombreDirector() {
        return nombreDirector;
    }

    public investigadores[] getInv() {
        return inv;
    }
    
    double dineroTotalOtorgado(){
        
        double dineroTotal = 0;
        for(int i=0;i<dimL;i++){
            dineroTotal = dineroTotal + inv[i].montoTotal();
        }
        return dineroTotal; 
    }
    
    public String toString(){
    String aux = "";        
        aux = aux + "nombre del proyecto: " + nombreProyecto + " codigo: " + codigo + " nombre del director: " + nombreDirector + "\n";
        
        for(int i=0;i<dimL;i++){
            aux = aux + inv[i].toString();
        }
        return aux;         
    }
}
